# Job plug-in API list

|API Name|Support API version|
| --- | --- |
| VSDlgSetDialogTitle|3.0.0.1 ~|
| VSDlgAddField|3.0.0.1 ~|
| VSDlgGetIntValue|3.0.0.1 ~|
| VSDlgGetBoolValue|3.0.0.1 ~|
| VSDlgGetFloatValue|3.0.0.1 ~|
| VSDlgGetStringValue|3.0.0.1 ~|
| VSDlgDoModal|3.0.0.1 ~|
| VSMessageBox|3.0.0.1 ~|
| VSGetSequenceName|3.0.0.1 ~|
| VSGetSequencePath|3.0.0.1 ~|
| VSGetResolution|3.0.0.1 ~|
| VSGetPreMeasure|3.0.1.0 ~|
| VSGetPreMeasureInTick|3.0.1.0 ~|
| VSSeekToBeginTempo|3.0.0.1 ~|
| VSGetNextTempo|3.0.0.1 ~|
| VSSeekToBeginTimeSig|3.0.0.1 ~|
| VSGetNextTimeSig|3.0.0.1 ~|
| VSGetTempoAt|3.0.0.1 ~|
| VSGetTimeSigAt|3.0.0.1 ~|
| VSGetMusicalPart|3.0.0.1 ~|
| VSUpdateMusicalPart|3.0.0.1 ~|
| VSGetMusicalPartSinger|3.0.0.1 ~|
| VSSeekToBeginNote|3.0.0.1 ~|
| VSGetNextNote|3.0.0.1 ~|
| VSGetNextNoteEx|3.0.0.1 ~|
| VSUpdateNote|3.0.0.1 ~|
| VSUpdateNoteEx|3.0.0.1 ~|
| VSInsertNote|3.0.0.1 ~|
| VSInsertNoteEx|3.0.0.1 ~|
| VSRemoveNote|3.0.0.1 ~|
| VSGetControlAt|3.0.0.1 ~|
| VSUpdateControlAt|3.0.0.1 ~|
| VSSeekToBeginControl|3.0.0.1 ~|
| VSGetNextControl|3.0.0.1 ~|
| VSUpdateControl|3.0.0.1 ~|
| VSInsertControl|3.0.0.1 ~|
| VSRemoveControl|3.0.0.1 ~|
| VSGetDefaultControlValue|3.0.0.1 ~|
| VSSeekToBeginMonoWAVPart|3.0.0.1 ~|
| VSGetNextMonoWAVPart|3.0.0.1 ~|
| VSGetStereoWAVPart|3.0.0.1 ~|
| VSGetAudioDeviceName|3.0.1.0 ~|